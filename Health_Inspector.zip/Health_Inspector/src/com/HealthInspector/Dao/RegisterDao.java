package com.HealthInspector.Dao;

import com.HealthInspector.bean.Register;

public interface RegisterDao {
	boolean getregester(Register register);
}
