package com.HealthInspector.Dao;

import com.HealthInspector.bean.Login;

public interface HealthInspectorDao {
 public boolean validatelogin(Login login);
}
