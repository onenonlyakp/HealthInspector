package com.HealthInspector.Dao;

import com.HealthInspector.bean.Doctor;


public interface DoctorRegisterDao {
	boolean getregester(Doctor doctor);
}
