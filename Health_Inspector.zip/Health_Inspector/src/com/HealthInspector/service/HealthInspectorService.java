package com.HealthInspector.service;

import com.HealthInspector.bean.Login;

public interface HealthInspectorService {
	 public boolean validatelogin(Login login );
	}
