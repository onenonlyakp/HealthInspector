package com.HealthInspector.service;

import com.HealthInspector.bean.Register;

public interface RegisterService {
	boolean getregester(Register register);

}
