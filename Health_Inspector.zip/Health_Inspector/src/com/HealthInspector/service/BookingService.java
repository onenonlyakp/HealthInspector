package com.HealthInspector.service;

import com.HealthInspector.bean.Appointment;

public interface BookingService {

	boolean book(Appointment app);

}
