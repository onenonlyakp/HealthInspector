package com.HealthInspector.service;

import com.HealthInspector.bean.Doctor;

public interface DoctorRegisterService {
	boolean getregester(Doctor doctor);

}
